const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sequelize = require('./src/config/database');
const authRoutes = require('./src/routes/auth');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));

// Register routes
app.use('/api/auth', authRoutes);

// Basic test route
app.get('/', (req, res) => {
  res.send('Hello, World !');
});

// Connect to DB and start server
sequelize.authenticate()
  .then(() => {
    console.log('✅ DB Connected');
    return sequelize.sync(); // Ensure tables are created
  })
  .then(() => {
    console.log('📡 Starting server...');
    app.listen(process.env.PORT || 3000, () => {
      console.log(`🚀 Server running on port ${process.env.PORT || 3000}`);
    });
  })
  .catch(err => {
    console.error('❌ DB connection error:', err);
  });
