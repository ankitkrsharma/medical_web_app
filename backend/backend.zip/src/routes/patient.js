const express = require('express');
const router = express.Router();
const controller = require('../controller/patient');
const authMiddleware = require('../config/authorization');

router.post('/add', authMiddleware, controller.addPatient);
router.get('/list', authMiddleware, controller.getPatients);

module.exports = router;