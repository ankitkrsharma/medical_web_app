const express = require('express');
const router = express.Router();
const lungScanController = require('../controller/lungScan');
const authMiddleware = require('../config/authorization');
const upload = require('../utils/multer');

router.post('/lung-scans', authMiddleware, upload.single('image'), lungScanController.uploadLungScan);
router.get('/list', authMiddleware, lungScanController.getAllLungScans);

module.exports = router;
