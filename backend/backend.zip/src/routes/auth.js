const express = require('express');
const router = express.Router();
const authController = require('../controller/auth');
const verifyToken = require('../middleware/authMiddleware');

router.post('/signup', authController.signup);
router.post('/login', authController.login);

// ✅ Only one /me route using token verification
router.get('/me', verifyToken, authController.getCurrentUser);

module.exports = router;
